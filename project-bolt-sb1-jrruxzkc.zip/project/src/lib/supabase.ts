import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Restaurant = {
  id: string;
  user_id: string;
  name: string;
  description: string;
  logo_url?: string;
  banner_url?: string;
  slug: string;
  theme_bg_color: string;
  theme_button_color: string;
  theme_text_color: string;
  created_at: string;
  updated_at: string;
};

export type MenuItem = {
  id: string;
  restaurant_id: string;
  name: string;
  description: string;
  price: number;
  image_url?: string;
  category: string;
  extra_options: string;
  discount: string;
  is_available: boolean;
  created_at: string;
  updated_at: string;
};

export type Order = {
  id: string;
  restaurant_id: string;
  customer_name: string;
  customer_email?: string;
  customer_phone?: string;
  delivery_address?: string;
  payment_method: string;
  status: 'pending' | 'preparing' | 'ready' | 'completed' | 'cancelled';
  total_amount: number;
  notes: string;
  created_at: string;
  updated_at: string;
};

export type OrderItem = {
  id: string;
  order_id: string;
  menu_item_id: string;
  quantity: number;
  price_at_order: number;
  special_instructions: string;
};

export type BusinessHours = {
  id: string;
  restaurant_id: string;
  day_of_week: number;
  opening_time: string;
  closing_time: string;
  is_closed: boolean;
};

export type PaymentMethod = {
  id: string;
  restaurant_id: string;
  method_name: string;
  is_enabled: boolean;
};

export type Review = {
  id: string;
  restaurant_id: string;
  order_id?: string;
  menu_item_id?: string;
  customer_name: string;
  rating: number;
  comment: string;
  created_at: string;
};
