import { useEffect, useState } from 'react';
import { supabase, Restaurant } from '../lib/supabase';
import { Save, Copy, Check, Upload } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type CustomizationProps = {
  restaurantId?: string;
  onRestaurantCreated?: (id: string) => void;
};

export default function Customization({ restaurantId, onRestaurantCreated }: CustomizationProps) {
  const { user } = useAuth();
  const [restaurant, setRestaurant] = useState<Partial<Restaurant>>({
    name: '',
    description: '',
    slug: '',
    theme_bg_color: '#ffffff',
    theme_button_color: '#f97316',
    theme_text_color: '#000000',
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (restaurantId) {
      loadRestaurant();
    }
  }, [restaurantId]);

  const loadRestaurant = async () => {
    if (!restaurantId) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .eq('id', restaurantId)
      .maybeSingle();

    if (data) {
      setRestaurant(data);
    }
    setLoading(false);
  };

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
  };

  const handleSave = async () => {
    if (!restaurant.name || !restaurant.slug) {
      alert('Nome e slug são obrigatórios');
      return;
    }

    setSaving(true);

    if (restaurantId) {
      const { error } = await supabase
        .from('restaurants')
        .update({
          ...restaurant,
          updated_at: new Date().toISOString(),
        })
        .eq('id', restaurantId);

      if (error) {
        alert('Erro ao salvar: ' + error.message);
      } else {
        alert('Alterações salvas com sucesso!');
      }
    } else {
      const { data, error } = await supabase
        .from('restaurants')
        .insert({
          ...restaurant,
          user_id: user?.id,
        })
        .select()
        .single();

      if (error) {
        alert('Erro ao criar restaurante: ' + error.message);
      } else if (data) {
        alert('Restaurante criado com sucesso!');
        onRestaurantCreated?.(data.id);
      }
    }

    setSaving(false);
  };

  const copyLink = () => {
    const link = `${window.location.origin}/menu/${restaurant.slug}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Personalização do Restaurante</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Nome do Restaurante
          </label>
          <input
            type="text"
            value={restaurant.name}
            onChange={(e) => {
              const name = e.target.value;
              setRestaurant({ ...restaurant, name, slug: generateSlug(name) });
            }}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="Ex: Pizzaria Bella"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Descrição
          </label>
          <textarea
            value={restaurant.description}
            onChange={(e) => setRestaurant({ ...restaurant, description: e.target.value })}
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="Descreva seu restaurante..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Slug (URL do cardápio)
          </label>
          <input
            type="text"
            value={restaurant.slug}
            onChange={(e) => setRestaurant({ ...restaurant, slug: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="Ex: pizzaria-bella"
          />
          <p className="text-sm text-gray-500 mt-1">
            Seu cardápio estará disponível em: /menu/{restaurant.slug}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cor de Fundo
            </label>
            <div className="flex gap-2">
              <input
                type="color"
                value={restaurant.theme_bg_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_bg_color: e.target.value })}
                className="h-10 w-16 border border-gray-300 rounded cursor-pointer"
              />
              <input
                type="text"
                value={restaurant.theme_bg_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_bg_color: e.target.value })}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cor dos Botões
            </label>
            <div className="flex gap-2">
              <input
                type="color"
                value={restaurant.theme_button_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_button_color: e.target.value })}
                className="h-10 w-16 border border-gray-300 rounded cursor-pointer"
              />
              <input
                type="text"
                value={restaurant.theme_button_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_button_color: e.target.value })}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cor dos Textos
            </label>
            <div className="flex gap-2">
              <input
                type="color"
                value={restaurant.theme_text_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_text_color: e.target.value })}
                className="h-10 w-16 border border-gray-300 rounded cursor-pointer"
              />
              <input
                type="text"
                value={restaurant.theme_text_color}
                onChange={(e) => setRestaurant({ ...restaurant, theme_text_color: e.target.value })}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors disabled:opacity-50"
          >
            <Save className="w-5 h-5" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </button>

          {restaurantId && restaurant.slug && (
            <button
              onClick={copyLink}
              className="flex items-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 transition-colors"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              {copied ? 'Link Copiado!' : 'Copiar Link do Cardápio'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
