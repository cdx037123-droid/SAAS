import { useEffect, useState } from 'react';
import { supabase, BusinessHours, PaymentMethod } from '../lib/supabase';
import { Save } from 'lucide-react';

type SettingsProps = {
  restaurantId: string;
};

const daysOfWeek = [
  { value: 0, label: 'Domingo' },
  { value: 1, label: 'Segunda-feira' },
  { value: 2, label: 'Terça-feira' },
  { value: 3, label: 'Quarta-feira' },
  { value: 4, label: 'Quinta-feira' },
  { value: 5, label: 'Sexta-feira' },
  { value: 6, label: 'Sábado' },
];

const paymentMethodOptions = [
  'Dinheiro',
  'Cartão de Crédito',
  'Cartão de Débito',
  'Pix',
  'Vale Refeição',
  'Vale Alimentação',
];

export default function Settings({ restaurantId }: SettingsProps) {
  const [businessHours, setBusinessHours] = useState<BusinessHours[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, [restaurantId]);

  const loadSettings = async () => {
    setLoading(true);

    const [hoursResult, paymentsResult] = await Promise.all([
      supabase.from('business_hours').select('*').eq('restaurant_id', restaurantId).order('day_of_week'),
      supabase.from('payment_methods').select('*').eq('restaurant_id', restaurantId),
    ]);

    if (hoursResult.data) {
      const existingDays = hoursResult.data.map((h) => h.day_of_week);
      const missingDays = daysOfWeek.filter((d) => !existingDays.includes(d.value));

      const allHours = [
        ...hoursResult.data,
        ...missingDays.map((d) => ({
          id: `temp-${d.value}`,
          restaurant_id: restaurantId,
          day_of_week: d.value,
          opening_time: '09:00',
          closing_time: '18:00',
          is_closed: false,
        } as BusinessHours)),
      ].sort((a, b) => a.day_of_week - b.day_of_week);

      setBusinessHours(allHours);
    }

    if (paymentsResult.data) {
      const existingMethods = paymentsResult.data.map((p) => p.method_name);
      const missingMethods = paymentMethodOptions.filter((m) => !existingMethods.includes(m));

      const allMethods = [
        ...paymentsResult.data,
        ...missingMethods.map((m) => ({
          id: `temp-${m}`,
          restaurant_id: restaurantId,
          method_name: m,
          is_enabled: false,
        } as PaymentMethod)),
      ];

      setPaymentMethods(allMethods);
    }

    setLoading(false);
  };

  const handleSaveBusinessHours = async () => {
    setSaving(true);

    for (const hour of businessHours) {
      if (hour.id.startsWith('temp-')) {
        await supabase.from('business_hours').insert({
          restaurant_id: restaurantId,
          day_of_week: hour.day_of_week,
          opening_time: hour.opening_time,
          closing_time: hour.closing_time,
          is_closed: hour.is_closed,
        });
      } else {
        await supabase
          .from('business_hours')
          .update({
            opening_time: hour.opening_time,
            closing_time: hour.closing_time,
            is_closed: hour.is_closed,
          })
          .eq('id', hour.id);
      }
    }

    for (const method of paymentMethods) {
      if (method.id.startsWith('temp-')) {
        await supabase.from('payment_methods').insert({
          restaurant_id: restaurantId,
          method_name: method.method_name,
          is_enabled: method.is_enabled,
        });
      } else {
        await supabase
          .from('payment_methods')
          .update({
            is_enabled: method.is_enabled,
          })
          .eq('id', method.id);
      }
    }

    setSaving(false);
    alert('Configurações salvas com sucesso!');
    loadSettings();
  };

  const updateBusinessHour = (dayOfWeek: number, field: keyof BusinessHours, value: any) => {
    setBusinessHours((prev) =>
      prev.map((h) => (h.day_of_week === dayOfWeek ? { ...h, [field]: value } : h))
    );
  };

  const togglePaymentMethod = (methodName: string) => {
    setPaymentMethods((prev) =>
      prev.map((m) => (m.method_name === methodName ? { ...m, is_enabled: !m.is_enabled } : m))
    );
  };

  if (loading) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Configurações</h1>

      <div className="space-y-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Horário de Funcionamento</h2>
          <div className="space-y-4">
            {daysOfWeek.map((day) => {
              const hour = businessHours.find((h) => h.day_of_week === day.value);
              if (!hour) return null;

              return (
                <div key={day.value} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="w-32">
                    <span className="font-medium text-gray-800">{day.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={hour.is_closed}
                      onChange={(e) => updateBusinessHour(day.value, 'is_closed', e.target.checked)}
                      className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                    />
                    <label className="text-sm text-gray-600">Fechado</label>
                  </div>
                  {!hour.is_closed && (
                    <>
                      <input
                        type="time"
                        value={hour.opening_time}
                        onChange={(e) => updateBusinessHour(day.value, 'opening_time', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      />
                      <span className="text-gray-600">até</span>
                      <input
                        type="time"
                        value={hour.closing_time}
                        onChange={(e) => updateBusinessHour(day.value, 'closing_time', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      />
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Métodos de Pagamento</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {paymentMethods.map((method) => (
              <div
                key={method.method_name}
                className={`flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                  method.is_enabled
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
                onClick={() => togglePaymentMethod(method.method_name)}
              >
                <input
                  type="checkbox"
                  checked={method.is_enabled}
                  onChange={() => {}}
                  className="w-5 h-5 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                />
                <span className="font-medium text-gray-800">{method.method_name}</span>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleSaveBusinessHours}
          disabled={saving}
          className="flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors disabled:opacity-50"
        >
          <Save className="w-5 h-5" />
          {saving ? 'Salvando...' : 'Salvar Configurações'}
        </button>
      </div>
    </div>
  );
}
