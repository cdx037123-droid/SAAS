import { useEffect, useState } from 'react';
import { supabase, Order } from '../lib/supabase';
import { TrendingUp, ShoppingBag, DollarSign, Star } from 'lucide-react';

type DashboardProps = {
  restaurantId: string;
};

export default function Dashboard({ restaurantId }: DashboardProps) {
  const [stats, setStats] = useState({
    totalOrders: 0,
    pendingOrders: 0,
    totalRevenue: 0,
    averageRating: 0,
  });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [restaurantId]);

  const loadDashboardData = async () => {
    setLoading(true);

    const [ordersResult, revenueResult, reviewsResult, recentOrdersResult] = await Promise.all([
      supabase.from('orders').select('*', { count: 'exact' }).eq('restaurant_id', restaurantId),
      supabase.from('orders').select('total_amount').eq('restaurant_id', restaurantId).eq('status', 'completed'),
      supabase.from('reviews').select('rating').eq('restaurant_id', restaurantId),
      supabase.from('orders').select('*').eq('restaurant_id', restaurantId).order('created_at', { ascending: false }).limit(5),
    ]);

    const pendingCount = ordersResult.data?.filter((o) => o.status === 'pending' || o.status === 'preparing').length || 0;
    const totalRevenue = revenueResult.data?.reduce((sum, order) => sum + Number(order.total_amount), 0) || 0;
    const avgRating = reviewsResult.data?.length
      ? reviewsResult.data.reduce((sum, r) => sum + r.rating, 0) / reviewsResult.data.length
      : 0;

    setStats({
      totalOrders: ordersResult.count || 0,
      pendingOrders: pendingCount,
      totalRevenue,
      averageRating: avgRating,
    });

    setRecentOrders(recentOrdersResult.data || []);
    setLoading(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('pt-BR');
  };

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      preparing: 'bg-blue-100 text-blue-800',
      ready: 'bg-green-100 text-green-800',
      completed: 'bg-gray-100 text-gray-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  const getStatusLabel = (status: string) => {
    const labels = {
      pending: 'Pendente',
      preparing: 'Em Preparação',
      ready: 'Pronto',
      completed: 'Concluído',
      cancelled: 'Cancelado',
    };
    return labels[status as keyof typeof labels] || status;
  };

  if (loading) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-orange-100 p-3 rounded-lg">
              <ShoppingBag className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Total de Pedidos</h3>
          <p className="text-3xl font-bold text-gray-800">{stats.totalOrders}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Pedidos Ativos</h3>
          <p className="text-3xl font-bold text-gray-800">{stats.pendingOrders}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Receita Total</h3>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(stats.totalRevenue)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Avaliação Média</h3>
          <p className="text-3xl font-bold text-gray-800">{stats.averageRating.toFixed(1)}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-800">Pedidos Recentes</h2>
        </div>
        <div className="p-6">
          {recentOrders.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhum pedido ainda</p>
          ) : (
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{order.customer_name}</p>
                    <p className="text-sm text-gray-500">{formatDate(order.created_at)}</p>
                  </div>
                  <div className="text-right mr-4">
                    <p className="font-bold text-gray-800">{formatCurrency(Number(order.total_amount))}</p>
                    <p className="text-sm text-gray-500">{order.payment_method}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {getStatusLabel(order.status)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
