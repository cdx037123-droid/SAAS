import { useEffect, useState } from 'react';
import { supabase, Restaurant, MenuItem, PaymentMethod } from '../lib/supabase';
import { ShoppingCart, Minus, Plus, X, Check } from 'lucide-react';

type PublicMenuProps = {
  slug: string;
};

type CartItem = {
  menuItem: MenuItem;
  quantity: number;
  specialInstructions: string;
};

export default function PublicMenu({ slug }: PublicMenuProps) {
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [loading, setLoading] = useState(true);
  const [customerData, setCustomerData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    paymentMethod: '',
    notes: '',
  });
  const [orderSuccess, setOrderSuccess] = useState(false);

  useEffect(() => {
    loadRestaurantData();
  }, [slug]);

  const loadRestaurantData = async () => {
    setLoading(true);

    const { data: restaurantData } = await supabase
      .from('restaurants')
      .select('*')
      .eq('slug', slug)
      .maybeSingle();

    if (!restaurantData) {
      setLoading(false);
      return;
    }

    setRestaurant(restaurantData);

    const [menuResult, paymentsResult] = await Promise.all([
      supabase.from('menu_items').select('*').eq('restaurant_id', restaurantData.id).eq('is_available', true).order('category'),
      supabase.from('payment_methods').select('*').eq('restaurant_id', restaurantData.id).eq('is_enabled', true),
    ]);

    if (menuResult.data) setMenuItems(menuResult.data);
    if (paymentsResult.data) setPaymentMethods(paymentsResult.data);

    setLoading(false);
  };

  const addToCart = (menuItem: MenuItem) => {
    const existing = cart.find((item) => item.menuItem.id === menuItem.id);
    if (existing) {
      setCart(cart.map((item) =>
        item.menuItem.id === menuItem.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { menuItem, quantity: 1, specialInstructions: '' }]);
    }
    setShowCart(true);
  };

  const updateQuantity = (menuItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.menuItem.id === menuItemId
            ? { ...item, quantity: Math.max(0, item.quantity + delta) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const updateInstructions = (menuItemId: string, instructions: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.menuItem.id === menuItemId
          ? { ...item, specialInstructions: instructions }
          : item
      )
    );
  };

  const getTotalAmount = () => {
    return cart.reduce((sum, item) => sum + Number(item.menuItem.price) * item.quantity, 0);
  };

  const handleCheckout = async () => {
    if (!restaurant || cart.length === 0) return;

    if (!customerData.name || !customerData.paymentMethod) {
      alert('Preencha pelo menos seu nome e método de pagamento');
      return;
    }

    const totalAmount = getTotalAmount();

    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .insert({
        restaurant_id: restaurant.id,
        customer_name: customerData.name,
        customer_email: customerData.email,
        customer_phone: customerData.phone,
        delivery_address: customerData.address,
        payment_method: customerData.paymentMethod,
        status: 'pending',
        total_amount: totalAmount,
        notes: customerData.notes,
      })
      .select()
      .single();

    if (orderError || !orderData) {
      alert('Erro ao criar pedido: ' + orderError?.message);
      return;
    }

    const orderItems = cart.map((item) => ({
      order_id: orderData.id,
      menu_item_id: item.menuItem.id,
      quantity: item.quantity,
      price_at_order: item.menuItem.price,
      special_instructions: item.specialInstructions,
    }));

    const { error: itemsError } = await supabase.from('order_items').insert(orderItems);

    if (itemsError) {
      alert('Erro ao adicionar itens: ' + itemsError.message);
      return;
    }

    setOrderSuccess(true);
    setCart([]);
    setTimeout(() => {
      setShowCheckout(false);
      setOrderSuccess(false);
      setCustomerData({
        name: '',
        email: '',
        phone: '',
        address: '',
        paymentMethod: '',
        notes: '',
      });
    }, 3000);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const groupedItems = menuItems.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Carregando cardápio...</p>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Restaurante não encontrado</p>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen pb-20"
      style={{ backgroundColor: restaurant.theme_bg_color, color: restaurant.theme_text_color }}
    >
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2">{restaurant.name}</h1>
          <p className="text-lg opacity-80">{restaurant.description}</p>
        </div>

        <div className="space-y-8">
          {Object.entries(groupedItems).map(([category, items]) => (
            <div key={category}>
              <h2 className="text-2xl font-bold mb-4">{category}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {items.map((item) => (
                  <div key={item.id} className="bg-white bg-opacity-95 rounded-lg p-4 shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800">{item.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-lg font-bold" style={{ color: restaurant.theme_button_color }}>
                        {formatCurrency(Number(item.price))}
                      </span>
                      <button
                        onClick={() => addToCart(item)}
                        className="px-4 py-2 rounded-lg text-white font-medium hover:opacity-90 transition-opacity"
                        style={{ backgroundColor: restaurant.theme_button_color }}
                      >
                        Adicionar
                      </button>
                    </div>
                    {item.discount && (
                      <p className="text-xs mt-2" style={{ color: restaurant.theme_button_color }}>
                        {item.discount}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg p-4">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowCart(!showCart)}
                className="flex items-center gap-2 text-gray-800 font-semibold"
              >
                <ShoppingCart className="w-6 h-6" />
                <span>{cart.length} {cart.length === 1 ? 'item' : 'itens'}</span>
              </button>
              <span className="text-xl font-bold text-gray-800">{formatCurrency(getTotalAmount())}</span>
            </div>
            <button
              onClick={() => {
                setShowCart(false);
                setShowCheckout(true);
              }}
              className="px-6 py-3 rounded-lg text-white font-semibold hover:opacity-90 transition-opacity"
              style={{ backgroundColor: restaurant.theme_button_color }}
            >
              Finalizar Pedido
            </button>
          </div>
        </div>
      )}

      {showCart && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-800">Seu Pedido</h2>
              <button onClick={() => setShowCart(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {cart.map((item) => (
                <div key={item.menuItem.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800">{item.menuItem.name}</h3>
                      <p className="text-sm text-gray-600">{formatCurrency(Number(item.menuItem.price))}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.menuItem.id, -1)}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center font-semibold">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.menuItem.id, 1)}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={item.specialInstructions}
                    onChange={(e) => updateInstructions(item.menuItem.id, e.target.value)}
                    placeholder="Observações (opcional)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showCheckout && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {orderSuccess ? (
              <div className="p-12 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-green-100 p-4 rounded-full">
                    <Check className="w-12 h-12 text-green-600" />
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Pedido Realizado!</h2>
                <p className="text-gray-600">Seu pedido foi enviado para o restaurante.</p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between p-6 border-b border-gray-200">
                  <h2 className="text-2xl font-bold text-gray-800">Finalizar Pedido</h2>
                  <button onClick={() => setShowCheckout(false)} className="text-gray-500 hover:text-gray-700">
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Nome *</label>
                    <input
                      type="text"
                      value={customerData.name}
                      onChange={(e) => setCustomerData({ ...customerData, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={customerData.email}
                      onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Telefone</label>
                    <input
                      type="tel"
                      value={customerData.phone}
                      onChange={(e) => setCustomerData({ ...customerData, phone: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Endereço de Entrega</label>
                    <textarea
                      value={customerData.address}
                      onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })}
                      rows={2}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Método de Pagamento *</label>
                    <select
                      value={customerData.paymentMethod}
                      onChange={(e) => setCustomerData({ ...customerData, paymentMethod: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      required
                    >
                      <option value="">Selecione...</option>
                      {paymentMethods.map((method) => (
                        <option key={method.id} value={method.method_name}>
                          {method.method_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                    <textarea
                      value={customerData.notes}
                      onChange={(e) => setCustomerData({ ...customerData, notes: e.target.value })}
                      rows={3}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      placeholder="Instruções especiais para o pedido..."
                    />
                  </div>

                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-lg font-semibold text-gray-800">Total</span>
                      <span className="text-2xl font-bold text-gray-800">{formatCurrency(getTotalAmount())}</span>
                    </div>

                    <button
                      onClick={handleCheckout}
                      className="w-full py-3 rounded-lg text-white font-semibold hover:opacity-90 transition-opacity"
                      style={{ backgroundColor: restaurant.theme_button_color }}
                    >
                      Confirmar Pedido
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
