import { useEffect, useState } from 'react';
import { supabase, Order, MenuItem, Review } from '../lib/supabase';
import { TrendingUp, Package, Star } from 'lucide-react';

type ReportsProps = {
  restaurantId: string;
};

type SalesData = {
  daily: number;
  weekly: number;
  monthly: number;
};

type TopItem = {
  item: MenuItem;
  count: number;
  revenue: number;
};

export default function Reports({ restaurantId }: ReportsProps) {
  const [loading, setLoading] = useState(true);
  const [salesData, setSalesData] = useState<SalesData>({ daily: 0, weekly: 0, monthly: 0 });
  const [topItems, setTopItems] = useState<TopItem[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filter, setFilter] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  useEffect(() => {
    loadReports();
  }, [restaurantId, filter]);

  const loadReports = async () => {
    setLoading(true);

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    const [ordersResult, orderItemsResult, reviewsResult] = await Promise.all([
      supabase.from('orders').select('*').eq('restaurant_id', restaurantId).eq('status', 'completed'),
      supabase.from('order_items').select(`
        *,
        menu_items (*),
        orders!inner (restaurant_id, status, created_at)
      `).eq('orders.restaurant_id', restaurantId).eq('orders.status', 'completed'),
      supabase.from('reviews').select('*').eq('restaurant_id', restaurantId).order('created_at', { ascending: false }).limit(10),
    ]);

    if (ordersResult.data) {
      const dailyOrders = ordersResult.data.filter(o => new Date(o.created_at) >= today);
      const weeklyOrders = ordersResult.data.filter(o => new Date(o.created_at) >= weekAgo);
      const monthlyOrders = ordersResult.data.filter(o => new Date(o.created_at) >= monthAgo);

      setSalesData({
        daily: dailyOrders.reduce((sum, o) => sum + Number(o.total_amount), 0),
        weekly: weeklyOrders.reduce((sum, o) => sum + Number(o.total_amount), 0),
        monthly: monthlyOrders.reduce((sum, o) => sum + Number(o.total_amount), 0),
      });
    }

    if (orderItemsResult.data) {
      const itemMap = new Map<string, { item: MenuItem; count: number; revenue: number }>();

      orderItemsResult.data.forEach((orderItem: any) => {
        const filterDate = filter === 'daily' ? today : filter === 'weekly' ? weekAgo : monthAgo;
        if (new Date(orderItem.orders.created_at) < filterDate) return;

        const menuItem = orderItem.menu_items;
        const existing = itemMap.get(menuItem.id);

        if (existing) {
          existing.count += orderItem.quantity;
          existing.revenue += Number(orderItem.price_at_order) * orderItem.quantity;
        } else {
          itemMap.set(menuItem.id, {
            item: menuItem,
            count: orderItem.quantity,
            revenue: Number(orderItem.price_at_order) * orderItem.quantity,
          });
        }
      });

      const sorted = Array.from(itemMap.values()).sort((a, b) => b.count - a.count).slice(0, 5);
      setTopItems(sorted);
    }

    if (reviewsResult.data) {
      setReviews(reviewsResult.data);
    }

    setLoading(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('pt-BR');
  };

  if (loading) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Relatórios e Análises</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Vendas Hoje</h3>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(salesData.daily)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Vendas Últimos 7 Dias</h3>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(salesData.weekly)}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-orange-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm font-medium mb-1">Vendas Últimos 30 Dias</h3>
          <p className="text-3xl font-bold text-gray-800">{formatCurrency(salesData.monthly)}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-800">Produtos Mais Vendidos</h2>
          <div className="flex gap-2">
            {['daily', 'weekly', 'monthly'].map((period) => (
              <button
                key={period}
                onClick={() => setFilter(period as any)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filter === period
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {period === 'daily' ? 'Hoje' : period === 'weekly' ? '7 Dias' : '30 Dias'}
              </button>
            ))}
          </div>
        </div>

        {topItems.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Nenhuma venda no período selecionado</p>
        ) : (
          <div className="space-y-4">
            {topItems.map((topItem, index) => (
              <div key={topItem.item.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-center w-10 h-10 bg-orange-100 rounded-full">
                  <span className="text-lg font-bold text-orange-600">#{index + 1}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800">{topItem.item.name}</h3>
                  <p className="text-sm text-gray-600">{topItem.item.category}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-800">{topItem.count} vendidos</p>
                  <p className="text-sm text-green-600">{formatCurrency(topItem.revenue)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-2 mb-6">
          <Star className="w-6 h-6 text-yellow-500" />
          <h2 className="text-xl font-bold text-gray-800">Avaliações Recentes</h2>
        </div>

        {reviews.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Nenhuma avaliação ainda</p>
        ) : (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-800">{review.customer_name}</h3>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-2">{review.comment}</p>
                <p className="text-xs text-gray-500">{formatDate(review.created_at)}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
