import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { supabase } from './lib/supabase';
import Auth from './components/Auth';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Customization from './pages/Customization';
import Menu from './pages/Menu';
import Orders from './pages/Orders';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import PublicMenu from './pages/PublicMenu';

function AppContent() {
  const { user, loading: authLoading } = useAuth();
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'customization' | 'menu' | 'orders' | 'reports' | 'settings'>('dashboard');
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const isPublicMenuRoute = window.location.pathname.startsWith('/menu/');
  const slug = isPublicMenuRoute ? window.location.pathname.replace('/menu/', '') : null;

  useEffect(() => {
    if (!authLoading && user && !isPublicMenuRoute) {
      loadRestaurant();
    } else {
      setLoading(false);
    }
  }, [user, authLoading, isPublicMenuRoute]);

  const loadRestaurant = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('restaurants')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle();

    if (data) {
      setRestaurantId(data.id);
    }
    setLoading(false);
  };

  if (isPublicMenuRoute && slug) {
    return <PublicMenu slug={slug} />;
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-gray-600">Carregando...</p>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  if (!restaurantId) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">Bem-vindo!</h1>
          <p className="text-gray-600 mb-6">Configure seu restaurante para começar.</p>
          <Customization onRestaurantCreated={(id) => setRestaurantId(id)} />
        </div>
      </div>
    );
  }

  return (
    <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
      {currentPage === 'dashboard' && <Dashboard restaurantId={restaurantId} />}
      {currentPage === 'customization' && <Customization restaurantId={restaurantId} />}
      {currentPage === 'menu' && <Menu restaurantId={restaurantId} />}
      {currentPage === 'orders' && <Orders restaurantId={restaurantId} />}
      {currentPage === 'reports' && <Reports restaurantId={restaurantId} />}
      {currentPage === 'settings' && <Settings restaurantId={restaurantId} />}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
