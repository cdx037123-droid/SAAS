/*
  # Restaurant Management System Database Schema

  ## Overview
  This migration creates the complete database structure for a restaurant management system
  where restaurant owners can manage their profile, menu, orders, and view analytics.

  ## New Tables
  
  ### 1. `restaurants`
  Stores restaurant profile information and customization settings
  - `id` (uuid, primary key) - Unique restaurant identifier
  - `user_id` (uuid, foreign key) - Links to auth.users
  - `name` (text) - Restaurant name
  - `description` (text) - Restaurant description
  - `logo_url` (text) - URL to logo image
  - `banner_url` (text) - URL to banner image
  - `slug` (text, unique) - Unique URL slug for public menu
  - `theme_bg_color` (text) - Background color for theme
  - `theme_button_color` (text) - Button color for theme
  - `theme_text_color` (text) - Text color for theme
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `menu_items`
  Stores menu items/dishes for each restaurant
  - `id` (uuid, primary key) - Unique item identifier
  - `restaurant_id` (uuid, foreign key) - Links to restaurants
  - `name` (text) - Dish name
  - `description` (text) - Dish description
  - `price` (numeric) - Dish price
  - `image_url` (text) - URL to dish image
  - `category` (text) - Category (Entradas, Pratos Principais, etc.)
  - `extra_options` (text) - Additional customization options
  - `discount` (text) - Discount or promotion information
  - `is_available` (boolean) - Availability status
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 3. `orders`
  Stores customer orders
  - `id` (uuid, primary key) - Unique order identifier
  - `restaurant_id` (uuid, foreign key) - Links to restaurants
  - `customer_name` (text) - Customer name
  - `customer_email` (text) - Customer email
  - `customer_phone` (text) - Customer phone
  - `delivery_address` (text) - Delivery address
  - `payment_method` (text) - Selected payment method
  - `status` (text) - Order status (pending, preparing, ready, completed)
  - `total_amount` (numeric) - Total order amount
  - `notes` (text) - Special instructions
  - `created_at` (timestamptz) - Order creation time
  - `updated_at` (timestamptz) - Last status update time

  ### 4. `order_items`
  Stores individual items within each order
  - `id` (uuid, primary key) - Unique order item identifier
  - `order_id` (uuid, foreign key) - Links to orders
  - `menu_item_id` (uuid, foreign key) - Links to menu_items
  - `quantity` (integer) - Quantity ordered
  - `price_at_order` (numeric) - Price at time of order
  - `special_instructions` (text) - Item-specific instructions

  ### 5. `business_hours`
  Stores restaurant operating hours
  - `id` (uuid, primary key) - Unique record identifier
  - `restaurant_id` (uuid, foreign key) - Links to restaurants
  - `day_of_week` (integer) - Day (0=Sunday, 6=Saturday)
  - `opening_time` (time) - Opening time
  - `closing_time` (time) - Closing time
  - `is_closed` (boolean) - Whether restaurant is closed this day

  ### 6. `payment_methods`
  Stores accepted payment methods for each restaurant
  - `id` (uuid, primary key) - Unique record identifier
  - `restaurant_id` (uuid, foreign key) - Links to restaurants
  - `method_name` (text) - Payment method name
  - `is_enabled` (boolean) - Whether method is active

  ### 7. `reviews`
  Stores customer reviews and ratings
  - `id` (uuid, primary key) - Unique review identifier
  - `restaurant_id` (uuid, foreign key) - Links to restaurants
  - `order_id` (uuid, foreign key) - Links to orders
  - `menu_item_id` (uuid, foreign key, nullable) - Links to specific menu item
  - `customer_name` (text) - Reviewer name
  - `rating` (integer) - Rating (1-5 stars)
  - `comment` (text) - Review text
  - `created_at` (timestamptz) - Review creation time

  ## Security
  - Enable RLS on all tables
  - Restaurant owners can only access their own data
  - Public can view restaurant menus and place orders
  - Reviews are publicly readable but creation is controlled
*/

-- Create restaurants table
CREATE TABLE IF NOT EXISTS restaurants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  name text NOT NULL,
  description text DEFAULT '',
  logo_url text,
  banner_url text,
  slug text UNIQUE NOT NULL,
  theme_bg_color text DEFAULT '#ffffff',
  theme_button_color text DEFAULT '#3b82f6',
  theme_text_color text DEFAULT '#000000',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create menu_items table
CREATE TABLE IF NOT EXISTS menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text DEFAULT '',
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  image_url text,
  category text NOT NULL,
  extra_options text DEFAULT '',
  discount text DEFAULT '',
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  customer_name text NOT NULL,
  customer_email text,
  customer_phone text,
  delivery_address text,
  payment_method text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'preparing', 'ready', 'completed', 'cancelled')),
  total_amount numeric(10,2) NOT NULL CHECK (total_amount >= 0),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  menu_item_id uuid REFERENCES menu_items(id) NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  price_at_order numeric(10,2) NOT NULL CHECK (price_at_order >= 0),
  special_instructions text DEFAULT ''
);

-- Create business_hours table
CREATE TABLE IF NOT EXISTS business_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  day_of_week integer NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
  opening_time time NOT NULL,
  closing_time time NOT NULL,
  is_closed boolean DEFAULT false,
  UNIQUE(restaurant_id, day_of_week)
);

-- Create payment_methods table
CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  method_name text NOT NULL,
  is_enabled boolean DEFAULT true,
  UNIQUE(restaurant_id, method_name)
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  menu_item_id uuid REFERENCES menu_items(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies for restaurants
CREATE POLICY "Restaurant owners can view own restaurant"
  ON restaurants FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Restaurant owners can insert own restaurant"
  ON restaurants FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Restaurant owners can update own restaurant"
  ON restaurants FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Public can view restaurants by slug"
  ON restaurants FOR SELECT
  TO anon
  USING (true);

-- RLS Policies for menu_items
CREATE POLICY "Restaurant owners can view own menu items"
  ON menu_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = menu_items.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can insert own menu items"
  ON menu_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = menu_items.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can update own menu items"
  ON menu_items FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = menu_items.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = menu_items.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can delete own menu items"
  ON menu_items FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = menu_items.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can view available menu items"
  ON menu_items FOR SELECT
  TO anon
  USING (is_available = true);

-- RLS Policies for orders
CREATE POLICY "Restaurant owners can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = orders.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can update own orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = orders.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = orders.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can create orders"
  ON orders FOR INSERT
  TO anon
  WITH CHECK (true);

-- RLS Policies for order_items
CREATE POLICY "Restaurant owners can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      JOIN restaurants ON restaurants.id = orders.restaurant_id
      WHERE orders.id = order_items.order_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can create order items"
  ON order_items FOR INSERT
  TO anon
  WITH CHECK (true);

-- RLS Policies for business_hours
CREATE POLICY "Restaurant owners can manage own business hours"
  ON business_hours FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = business_hours.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = business_hours.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can view business hours"
  ON business_hours FOR SELECT
  TO anon
  USING (true);

-- RLS Policies for payment_methods
CREATE POLICY "Restaurant owners can manage own payment methods"
  ON payment_methods FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = payment_methods.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = payment_methods.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can view enabled payment methods"
  ON payment_methods FOR SELECT
  TO anon
  USING (is_enabled = true);

-- RLS Policies for reviews
CREATE POLICY "Restaurant owners can view own reviews"
  ON reviews FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = reviews.restaurant_id
      AND restaurants.user_id = auth.uid()
    )
  );

CREATE POLICY "Public can view reviews"
  ON reviews FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can create reviews"
  ON reviews FOR INSERT
  TO anon
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_restaurants_user_id ON restaurants(user_id);
CREATE INDEX IF NOT EXISTS idx_restaurants_slug ON restaurants(slug);
CREATE INDEX IF NOT EXISTS idx_menu_items_restaurant_id ON menu_items(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_id ON orders(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_business_hours_restaurant_id ON business_hours(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_payment_methods_restaurant_id ON payment_methods(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_reviews_restaurant_id ON reviews(restaurant_id);